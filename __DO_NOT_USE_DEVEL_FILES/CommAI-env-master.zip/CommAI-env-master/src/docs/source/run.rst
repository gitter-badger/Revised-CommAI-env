Running the competition
=======================

To run the competition, create a configuration file for the task scheduling,
for example, by copying the sample file::

  cp tasks_config.sample.json tasks_config.json

Then, run it with::

  python run.py tasks_config.json
