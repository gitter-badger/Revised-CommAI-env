core.obs.observer module
========================

.. automodule:: core.obs.observer
    :members:
    :undoc-members:
    :show-inheritance:
