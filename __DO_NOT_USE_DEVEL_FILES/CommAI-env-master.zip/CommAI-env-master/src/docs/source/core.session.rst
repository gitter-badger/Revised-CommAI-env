core.session module
===================

.. automodule:: core.session
    :members:
    :undoc-members:
    :show-inheritance:
