core package
============

Subpackages
-----------

.. toctree::

    core.obs

Submodules
----------

.. toctree::

   core.channels
   core.config_loader
   core.environment
   core.events
   core.scheduler
   core.serializer
   core.session
   core.task

Module contents
---------------

.. automodule:: core
    :members:
    :undoc-members:
    :show-inheritance:
