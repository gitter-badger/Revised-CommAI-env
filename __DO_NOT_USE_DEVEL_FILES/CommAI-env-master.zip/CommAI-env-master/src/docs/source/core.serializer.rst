core.serializer module
======================

.. automodule:: core.serializer
    :members:
    :undoc-members:
    :show-inheritance:
