view package
============

Submodules
----------

view.console module
-------------------

.. automodule:: view.console
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: view
    :members:
    :undoc-members:
    :show-inheritance:
