Testing the competition
=======================

If you are running Python 2.7+ you can run all the unit tests by going to `src`
directory and run::

  python -m unittest discover
