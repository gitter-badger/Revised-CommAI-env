core.obs package
================

Submodules
----------

.. toctree::

   core.obs.observer

Module contents
---------------

.. automodule:: core.obs
    :members:
    :undoc-members:
    :show-inheritance:
